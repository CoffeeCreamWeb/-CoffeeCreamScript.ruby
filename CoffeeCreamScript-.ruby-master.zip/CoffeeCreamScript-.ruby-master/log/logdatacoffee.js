
setlog{CoffeeCreamScript}
webdata{jekyll}
setadobe{adobeflashplayer}
