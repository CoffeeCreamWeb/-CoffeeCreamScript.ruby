<link.adobe.CoffeeCreamScript-.ruby>
<adobe.data.link>
<adobe.link.server>
