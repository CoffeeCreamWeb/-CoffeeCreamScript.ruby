<createfile>
<.ccj>
[name,CoffeeCreamJava]
<sethtmlcreate>
<typefile>
<html,apk,exe>
<service.jekyll.link>
