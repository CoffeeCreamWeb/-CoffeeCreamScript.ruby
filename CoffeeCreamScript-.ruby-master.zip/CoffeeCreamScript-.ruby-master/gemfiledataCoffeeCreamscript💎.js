source "https://rubygems.org"
gemspec
